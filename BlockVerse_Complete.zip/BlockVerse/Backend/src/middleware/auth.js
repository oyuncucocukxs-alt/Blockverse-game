'use strict';

const admin   = require('firebase-admin');
const jwt     = require('jsonwebtoken');
const { Player } = require('../models');

const JWT_SECRET  = process.env.JWT_SECRET || 'changeme-in-production';
const JWT_EXPIRY  = '24h';
const REFRESH_EXP = '30d';

// ─────────────────────────────────────────────
// Firebase Token → Internal JWT
// ─────────────────────────────────────────────

async function verifyFirebaseToken(idToken) {
  const decoded = await admin.auth().verifyIdToken(idToken);
  return {
    firebaseUid: decoded.uid,
    email:       decoded.email || '',
    emailVerified: decoded.email_verified || false,
  };
}

function signAccessToken(payload) {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: JWT_EXPIRY });
}

function signRefreshToken(payload) {
  return jwt.sign(payload, JWT_SECRET + '_refresh', { expiresIn: REFRESH_EXP });
}

function verifyAccessToken(token) {
  return jwt.verify(token, JWT_SECRET);
}

function verifyRefreshToken(token) {
  return jwt.verify(token, JWT_SECRET + '_refresh');
}

// ─────────────────────────────────────────────
// Express Auth Middleware
// ─────────────────────────────────────────────

async function requireAuth(req, res, next) {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Missing authorization token' });
  }

  const token = header.slice(7);
  try {
    const payload = verifyAccessToken(token);
    req.playerId = payload.playerId;
    req.firebaseUid = payload.firebaseUid;
    req.isAdmin = payload.isAdmin || false;
    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return res.status(401).json({ error: 'Token expired', code: 'TOKEN_EXPIRED' });
    }
    return res.status(401).json({ error: 'Invalid token' });
  }
}

async function requireAdmin(req, res, next) {
  await requireAuth(req, res, async () => {
    if (!req.isAdmin) {
      return res.status(403).json({ error: 'Admin access required' });
    }
    next();
  });
}

// ─────────────────────────────────────────────
// Game Server Token (for Unity dedicated server)
// ─────────────────────────────────────────────

async function requireServerAuth(req, res, next) {
  const serverSecret = req.headers['x-server-secret'];
  if (!serverSecret || serverSecret !== process.env.GAME_SERVER_SECRET) {
    return res.status(401).json({ error: 'Invalid server credentials' });
  }
  next();
}

// ─────────────────────────────────────────────
// Token validation endpoint (called by game server)
// ─────────────────────────────────────────────

async function validateGameToken(token) {
  try {
    const payload = verifyAccessToken(token);
    const player = await Player.findOne({ playerId: payload.playerId })
      .select('playerId username isBanned banExpiry isAdmin isModerator')
      .lean();

    if (!player) return { valid: false };

    // Check active ban
    if (player.isBanned) {
      if (player.banExpiry && new Date() > new Date(player.banExpiry)) {
        // Ban expired — lift it
        await Player.updateOne({ playerId: player.playerId }, {
          $set: { isBanned: false, banExpiry: null }
        });
      } else {
        return { valid: false, reason: 'banned' };
      }
    }

    return {
      valid: true,
      playerId: player.playerId,
      username: player.username,
      isAdmin: player.isAdmin,
      isModerator: player.isModerator,
    };
  } catch {
    return { valid: false };
  }
}

module.exports = {
  verifyFirebaseToken,
  signAccessToken,
  signRefreshToken,
  verifyAccessToken,
  verifyRefreshToken,
  requireAuth,
  requireAdmin,
  requireServerAuth,
  validateGameToken,
};
